<?php get_header();?>
<div class="content-wrap">
  <div class="row narrow">
    <div class="single-content">
      <h1>OOPS!<br>Page not found</h1>
      <a href="<?php echo get_bloginfo('home');?>" class="button rose">Повернутись на головну</a>
    </div>
  </div>
</div>
<?php get_footer();?>